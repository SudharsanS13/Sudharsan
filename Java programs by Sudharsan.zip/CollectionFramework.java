package Sudharsan;
import java.util.*;
public class CollectionFramework{
	public static void main(String[] args) {
	      ArrayDeque <String> deque = new ArrayDeque<String>();
	      
	      deque.add("Ram");
	      deque.add("Ramakrishnan");
	      deque.add("Ramyakrishnan");
	      
	      for(String ach:deque) {
	    	  System.out.println("Names :"+ ach);}
	      
	      System.out.println("Using clear");
	      deque.clear();
	      
	      deque.addFirst("Sri Ramakrishnan");
	      deque.addFirst("Raman");
	      deque.addLast("Sri Ram");
	      deque.addLast("kannan");
	      
	      System.out.println("Element of deque using Iterator:");
	      for(Iterator<String> itr = deque.iterator();itr.hasNext();) {
	    	  System.out.println(itr.next());}
	      
	      System.out.println("Elements of deque in reverse order :");
	      for(Iterator itr1 = deque.descendingIterator(); itr1.hasNext();) {
	    	  System.out.println(itr1.next());}
	      
	      System.out.println("head of the element :"+deque.element());
	      System.out.println("First element :"+deque.getFirst());
	      System.out.println("Last element :"+deque.getLast());
	      
	      Object arr[] = deque.toArray();
	      System.out.println("Array size :"+arr.length);
	      
	      System.out.println("Array elements :");
	      for(int i=0;i<arr.length;i++) {
	    	  System.out.println(" "+arr[i]);}
	      
	      System.out.println("head element :"+deque.peek());
	      System.out.println("Head element poll :"+deque.poll());
	      
	      deque.push("Aravind");
	      deque.push("Albert");
	      deque.push("Stephan");
	      
	      System.out.println("head elament remove :"+deque.remove());
	      System.out.println("the final array is :"+deque);
	 
	      }
	    }
 
