package simple;

public class Class {
	

}
