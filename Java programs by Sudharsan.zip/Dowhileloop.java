package Sudharsan;
import java.util.Scanner;
public class Dowhileloop {
	public static void main(String arg[]) {
		Scanner java= new Scanner(System.in);
		int n = java.nextInt();
		int i;
		for(i=2;i<=n;i+=2) {
		System.out.println(i);
		}
			
	}
}
