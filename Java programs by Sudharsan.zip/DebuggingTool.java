package javasample;

//Abstract class Debugger
abstract class Debugger {
 String errorMessage;

 // Constructor
 Debugger(String errorMessage) {
     this.errorMessage = errorMessage;
 }

 // Abstract method
 abstract void debug();

 // Common method to log the error
 void logError() {
     System.out.println("Logging Error: " + errorMessage);
 }
}

//Subclass for Syntax Errors
class SyntaxErrorDebugger extends Debugger {

 SyntaxErrorDebugger(String errorMessage) {
     super(errorMessage);
 }

 @Override
 void debug() {
     System.out.println("Debugging Syntax Error...");
     try {
         if (errorMessage.contains(";")) {
             throw new Exception("Unexpected token ';' found.");
         } else {
             System.out.println("No syntax issues found.");
         }
     } catch (Exception e) {
         System.out.println("Caught Syntax Exception: " + e.getMessage());
     }
 }
}

//Subclass for Runtime Errors
class RuntimeErrorDebugger extends Debugger {

 RuntimeErrorDebugger(String errorMessage) {
     super(errorMessage);
 }

 @Override
 void debug() {
     System.out.println("Debugging Runtime Error...");
     try {
         int result = 10 / 0; // This will throw ArithmeticException
         System.out.println("Result: " + result);
     } catch (ArithmeticException e) {
         System.out.println("Caught Runtime Exception: " + e.getMessage());
     }
 }
}

//Main class
public class DebuggingTool {
 public static void main(String[] args) {
     // Create instances of error debuggers
     Debugger syntaxDebugger = new SyntaxErrorDebugger("Missing semicolon;");
     Debugger runtimeDebugger = new RuntimeErrorDebugger("Division by zero");

     // Debug each error
     syntaxDebugger.logError();
     syntaxDebugger.debug();

     System.out.println();

     runtimeDebugger.logError();
     runtimeDebugger.debug();
 }
}
