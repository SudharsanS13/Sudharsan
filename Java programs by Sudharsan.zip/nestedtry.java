package Class;
public class nestedtry {
public static void main(String arg[]) {
	try {
		try {
			System.out.println("Going to Dive");
			int b = 50/2;
			System.out.println(b);
		}
		catch(Exception s){
			System.out.println(s);
		}
		try {
			int a[]=new int[50];
			a[20]=40;
		}
		catch(Exception p){
			System.out.println("its"+p);
		}
	}
	catch(Exception k) {
		System.out.println(k);
	}
	System.out.println("normal flow.....");
}
}
