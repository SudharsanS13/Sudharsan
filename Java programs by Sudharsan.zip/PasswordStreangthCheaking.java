package packag;
import java.util.Scanner;
public class PasswordStreangthCheaking {
public static void main(String args[])
{
	Scanner Op = new Scanner(System.in);
	System.out.print("Enter your Password : ");
	String pass = Op.nextLine();
	System.out.println("");
	
	String Strength = checkpasswordstrength(pass);
	System.out.println(Strength);
	}
public static String checkpasswordstrength(String pass) {
	int lengthcreteria = 8;
	boolean Uppercase = false;
	boolean Lowercase =false;
	boolean Digit = false;
	boolean Special = false;
	String specialcharacter = "!@#$%^*()_:<>?;',./'";
	
	if(pass.length()>=lengthcreteria) {
		for (char c : pass.toCharArray()) {
			if(Character.isUpperCase(c)) {
				Uppercase = true;
			}
			else if (Character.isLowerCase(c)) {
				Lowercase = true;
			}
			else if (Character.isDigit(c)) {
				Digit = true;
			}
			else if (specialcharacter.contains(String.valueOf(c))) {
				Special = true;
			}
		}
		if(Uppercase && Lowercase && Digit && Special) {
			return "Good! Secure Password!";
		}
		else {
			return "It is a Week Password.Please include 'Uppercase Letter','Lowercase letters','Numbers & Special Characters'sudharsan!";
		}
		}
	else {
		return "Password length must be atleast "+lengthcreteria+" Characters!";
	}
}
}
