package Class;
class sudharsan
{
    int age = 10;
    
}
public class Testperson {
	
public static void main(String arg[] ){
	sudharsan s = new sudharsan();
	System.out.println(s.age);
}
}
