package sudharsan1;
import java.util.Scanner;
public class array {
public static void main(String arg[]) {
	Scanner opt = new Scanner(System.in);
	int i,j,colms,rows;
	 int array[][]= {{13,25,34},
			         {90,56,67},
			         {35,57,3}};
	 System.out.print("Enter your rows :");
	 colms = opt.nextInt();
	 System.out.print("Enter your columns :");
	 rows = opt.nextInt();
	 int  transpose[][]= new int[colms][rows];
	 for(i=0;i<rows;i++) {
		 for(j=0;j<colms;j++) {
			 transpose[j][i] = array[i][j];
		 }
	 }
	 System.out.println("Transposed Array is");
	 for(i=0;i<colms;i++) {
		 System.out.println(" ");
		 for(j=0;j<rows;j++) {
			 System.out.print(" "+transpose[i][j]);
		 }
	 }
	 }
 }