package sudharsan;
class animals{
     void eat() {
	System.out.println("eating");		
	}
}
class new1 extends animals {
	 void dog() {
	 System.out.println("barking");				
	 }
}
class new2 extends animals{
	void cat() {
    System.out.println("Meow");		
	}
}
 class newinheritance{
    public static void main(String arg[]) {
    	new1 opt = new new1();
    	new2 op = new new2();
    	opt.dog();
    	op.cat();
    	opt.eat();
    }
}
