package javasample;
class Outerrr {
	private int a=5,b=450,c;
    class Inner {
        public void show()
        {
        	c = a*b;
        	System.out.println(c);
            System.out.println("In a nested class method");
        }
    }
}
public class Main {
    public static void main(String[] args)
    {
        Outerrr.Inner in = new Outerrr().new Inner();
        in.show();
    }
}