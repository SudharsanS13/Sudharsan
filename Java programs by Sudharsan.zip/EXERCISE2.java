package Sudharsan;
class Employee {
 private String name;
 private double salary;

 public Employee(String name, double salary) {
     this.name = name;
     this.salary = salary;
 }

 public double getSalary() {
     return salary;
 }

 public void displayDetails() {
     System.out.println("Employee Name: " + name);
     System.out.println("Salary: $" + salary);
 }
}

class Manager extends Employee {
 private double bonus;

 public Manager(String name, double salary, double bonus) {
     super(name, salary);
     this.bonus = bonus;
 }

 public void displayDetails() {
     super.displayDetails();
     System.out.println("Bonus: $" + bonus);
 }

 public double calculateTotalSalary() {
     return getSalary() + bonus;
 }
}

public class EXERCISE2 {
 public static void main(String[] args) {
     Employee employee = new Employee("John", 5000);
     Manager manager = new Manager("Alice", 7000, 2000);

     employee.displayDetails();
     System.out.println();
     manager.displayDetails();
     System.out.println("Total Salary: $" + manager.calculateTotalSalary());
 }
}





