package sudharsan;

public class builtin {
	public static void main(String arg[]) {
	int i;
	// lower & upper case 
	System.out.println("lower & upper case is:");
	System.out.println("");
	String s1 =  "I'm a SOFTWARE developer in a REPUTED company";
	String s2 = "alpha";
	String s3 = "alpha";
	String s4 = "ALPHA";
	String s5 = new String("Alpha");
	String strlower = s1.toLowerCase();
	System.out.println(strlower);
	String strupper = s1.toUpperCase();
	System.out.println(strupper);
	System.out.println("");
	// char array
	System.out.println("char array is:");
	System.out.println("");
	char [] opt = s1.toCharArray();
	 int len = opt.length;
	 System.out.println( "char length is:"+len);
	 System.out.println("char array element");
	 for(i=0;i<len;i++) {		 
		 System.out.println(opt[i]);
	}
	 System.out.println("");
	 // join
	 System.out.println("join buildin is:");
		System.out.println("");
	String st1 = String.join("$" ,"I have","12kpound","house");
	System.out.println(st1);
	String st2 = String.join(":","Best Hacker is", "Sudharsan")	;
	System.out.println(st2);
	String st3 = String.join("My Birthday Date is : 13","09","2003");
    System.out.println(st3);
    System.out.println("");
    // Equals
    System.out.println("Equals builtin is:");
	System.out.println("");
    System.out.println(s2==s3);
    System.out.println(s2==s4);
    System.out.println(s2.equals(s5));
    System.out.println(s2.equalsIgnoreCase(s4));
    System.out.println("");
    //cotains
    System.out.println("contains buildin is:");
	System.out.println("");
    System.out.println(s1.contains("SOFTWARE"));
    System.out.println(s1.contains("developer"));
    System.out.println(s1.contains("Hardware"));
    System.out.println("");
    //Substring
    System.out.println("Substring buildin is:");
	System.out.println("");
	String s20 = "SOFTWARE ENGINEERING";
    String str1 = s20.substring(0);
    System.out.println(""+str1);
    String str2 = s20.substring(4,6);
    System.out.println(""+str2);
    String str3 = s20.substring(4,19); 
    System.out.println(""+str3);
    System.out.println("");
    //length
    System.out.println("length builtin is:");
	System.out.println("");
    System.out.println("String s1 length is:"+s1.length());
    System.out.println("String st1 length is:"+st1.length());
    System.out.println("");
    //charat
    System.out.println("charat builtin is:");
	System.out.println("");
    char ch = s1.charAt(13);
    System.out.println("char letter is:"+ch);
    ch=s1.charAt(20);
    System.out.println("char letter is:"+ch);
}
	}
