package javasample;
import java.util.Scanner;
interface bank{
	float rateOfIntrest();
}
class BOI implements bank{
	Scanner op = new Scanner(System.in);
	public float rateOfIntrest() {
		final float i = op.nextFloat();
		return  (i);
	}
}
class CANARA implements bank{
	public float rateOfIntrest() {
		return (9.85f);
	}
}
class TMB implements bank{
	public float rateOfIntrest() {
		return (5.8f);
	}
}
public class interfase {
public static void main(String args[]) {
	BOI s1 = new BOI();
	TMB s2 = new TMB();
	CANARA s3 = new CANARA();
	System.out.println("BOI intrest : "+s1.rateOfIntrest());
	System.out.println("TMB intrest : "+s2.rateOfIntrest());
	System.out.println("CANARA intrest : "+s3.rateOfIntrest());


	
}
}
