package sample;
class student{
     int rollno;
	String name;
	static String collegename = "Vaigai College";
	static void change() {
		  collegename = "Vaigai College of Engineering";
	}
	student(int i,String s){
		rollno = i;
		name = s;
	}
	void display() {
		System.out.println(rollno + " "+name+" "+collegename);
	}
}
public class staticmethod {
public static void main(String arg[]) {
	student.change();
	student st = new student(211026,"Sudharsan");
	student st1 = new student(211023,"Krishna");
	student st2 = new student(211027,"Yogesh");
	st.display();
	st1.display();
	st2.display();

}
}