package sample;

public class nestedfun {
	void state() {
		System.out.print("My Dear ");
		country();
	}
		void country() {
			System.out.println("Peoples");	
		}
public static void main (String arg[]) {
   nestedfun b = new nestedfun();
   b.state();
}
}
