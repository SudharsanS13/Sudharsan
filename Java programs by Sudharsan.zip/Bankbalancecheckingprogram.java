package Class;
interface PaymentGateway{
	void makepayment(double amount) throws InsufficientBalanceException;
}
abstract class User implements PaymentGateway{
	String name;
	double Balance;
	User(String name,double Balance){
		this.name=name;
		this.Balance = Balance;
	}
	abstract void displayinfo();
}
class InsufficientBalanceException extends Exception{
	public InsufficientBalanceException(String message){
		super (message);
	}
}
class Customer extends User{
    private static int customercount = 0;
	public Customer(String name, double Balance) {
		super(name, Balance);
		this.name=name;
		this.Balance = Balance;
		customercount++;	
	}
	public static int getcustomercount() {
		return customercount;
	}
	
void displayinfo() {
	System.out.println("Customer name:"+name);
	System.out.println("Balance amount:"+Balance);
}
public void makePayment(double amount) throws InsufficientBalanceException {
	
	 if (amount > Balance) {
	        throw new InsufficientBalanceException("Payment failed: Insufficient balance.");
	    }
	    Balance -= amount;
	    System.out.println("Payment of $" + amount + " successful. New balance: $" + Balance);
}
}
class TransactionUtil {
    public static void printTransactionHeader() {
        System.out.println("=== TRANSACTION START ===");
    }

    public static void printTransactionFooter() {
        System.out.println("=== TRANSACTION END ===");
    }
}
public class Bankbalancecheckingprogram {
	public static void main(String args[]) {
		 Customer c = new Customer("Alice", 1000.0);
	        c.displayinfo();
	        System.out.println("Total Customers: " + Customer.getcustomercount());

	        TransactionUtil.printTransactionHeader();

	        try {
	            c.makePayment(300.0); 
	            c.makePayment(50.0);  
	            c.makePayment(650.0); 
	        } catch (InsufficientBalanceException e) {
	            System.err.println("Error: " + e.getMessage());
	        }

	        TransactionUtil.printTransactionFooter();
}
}