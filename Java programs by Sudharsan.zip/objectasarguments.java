package sample;
class one{
	int x,y;
    void two(int a,int b) {
		x = a;
		y = b;	
	}
	void sub(one s1) {
		int sub = s1.x - s1.y;
		System.out.println("Subraction answer is :"+sub);
	}
}
public class objectasarguments {
	public static void main(String arg[]) {
     one s = new one();
     s.two(13,9);
     s.sub(s);
}
}