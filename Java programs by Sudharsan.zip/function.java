package sudharsan;
import java.util.Scanner;
class overloading{
	double area(float l,float w,float h) {
	return	l*w*h;
}
    double area(float l) {
    return	l*l*l;
}
    double area(float r,float h) {
	return	3.1416*r*r*h;
    }
}
public class function {		
public static void main(String arg[]){
	Scanner box = new Scanner(System.in);
	overloading opt = new overloading();
	System.out.print("Enter the length : ");
	System.out.println("");
	int x = box.nextInt();
	System.out.print("Enter the width : ");
	System.out.println("");
	int y = box.nextInt();
	System.out.print("Enter the height : ");
	System.out.println("");
	int z = box.nextInt();
	System.out.print("Enter the radius : ");
	System.out.println("");
	int s = box.nextInt();
	double rectangleBox = opt.area(x,y,z);				
	System.out.println("Area of rectangle Box : "+rectangleBox);
	System.out.println("");
	double cube = opt.area(x);				
	System.out.println("Area of cube : "+cube);
	System.out.println("");
	double cylinder = opt.area(s,z);				
	System.out.println("Area of cylinder : "+cylinder);
	System.out.println("");
 }
}

