package javatraining1;
class Rectangle{
	
	private String name ;
	private int age;
	 public String getter() {
		return name;
	}
	 public void setter (String name1) {
		 name = name1;
	 }
	public int get() {
			return age;
		}
		public void set (int age1) {
			 if(age1>0) {
			 age = age1;
		 }
			 else {
				 System.out.println("Age is wrong");
			 }
}
}
public class packages {
public static void main(String args[]) {
Rectangle C = new Rectangle();
C.setter("Anush");
C.set(13);
System.out.println("Your name is :"+C.getter());
System.out.println(C.get());
}
}
