package Class;
import java.util.Scanner;
public class odd {
	public static void main (String arg[]) {
		Scanner opt = new Scanner(System.in);
		int i,j;
		int A[][]= new int[50][50];
		int B[][]= new int[50][50];
		int C[][]= new int[50][50];
		int r1= opt.nextInt();
		int r2 = opt.nextInt();
		int c1= opt.nextInt();
		int c2 = opt.nextInt();
		System.out.println("Enter the row & colum for 1st matrix:" +r1+c1);
		System.out.println("Enter the row & colum for 2nd matrix:" +r2+c2);
		if(r1==r2 || c1==c2) {
			System.out.println("your matrix is elgible for addition");
			System.out.println("Enter data for the 1st matrix");
			for(i=0;i<r1;i++) {
				for(j=0;j<c1;j++) {
					System.out.println("Enter the value");
					A[i][j] = opt.nextInt();
			
				}
			}
			System.out.println("Enter data for the 2nd matrix");
			for(i=0;i<r2;i++) {
				for(j=0;j<c2;j++) {
					System.out.println("Enter the value");
					B[i][j] = opt.nextInt();
					
				}
			}
			System.out.println(" ");
			System.out.println("Matrix is:");
			System.out.println(" ");
			for(i=0;i<r1;i++) {
				for(j=0;j<c1;j++) {
					C[i][j] = A[i][j] + B[i][j];
				}
			}
			System.out.println("First Matrix Data");
			for(i=0;i<r1;i++) {
				for(j=0;j<c1;j++) {
					System.out.print(" "+ A[i][j]);
				}
				System.out.println(" ");
			}
			System.out.println(" ");
			System.out.println("Second Matrix Data");
			for(i=0;i<r2;i++) {
				for(j=0;j<c2;j++) {
					System.out.print(" "+ B[i][j]);
				}
				System.out.println(" ");
			}
			System.out.println(" ");
			System.out.println("Output Matrix Data");
			for(i=0;i<r1;i++) {
				for(j=0;j<c1;j++) {
					System.out.print(" "+ C[i][j]);
				}
				System.out.println(" ");
			}
			System.out.println(" ");
		}
		else
		{
			System.out.println("sorry! Your matrix was not eligible for addition");
			System.out.println("because, it has different rows and columns");
		}
	}
	
}	
