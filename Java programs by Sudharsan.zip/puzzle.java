package javatraining;
import java.util.Arrays;
import java.util.Scanner;
 class  puzzle{
	
	 static int SIZE=16;
		static int i;
	    static int  puzzle []={4,11,2,13,0,3,7,14,15,1,12,5,6,10,8,9};
	  
 

	public static void main(String args[]) {
		 Scanner op = new Scanner(System.in);
		 while (!correctAlingn1()) {
			 correctAlingn1();
			 System.out.println("Enter the number to move :");
			 int move = op.nextInt();
			moveing(move);
		 }
		op.close();
		System.out.println("Congragulation! you solved the puzzle");
	}
	 
	  void nextline1() {
		   for (i=0;i<SIZE;i++) {
		   	System.out.println(puzzle[i]==0 ?" ":puzzle[i]+" ");
		   	if ((i+1) % 4==0) {
		   		System.out.println();
		     }
		   }
		}
	  static boolean correctAlingn1() { 	
			int[] correctarrang = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,0};
			return Arrays.equals(puzzle,correctarrang);    	
		}
		 static void moveing(int move) {
			 int Nindex=-1,Zindex=-1;
			 for(i=0;i<SIZE;i++) {
				 if (puzzle[i]==move) {
					 Nindex = i;
				 }
			 }
				 if (puzzle[i]==0) {
					 Zindex = i;
				 }
				 if(Nindex!= -1 && Math.abs(Nindex-Zindex)==1||Math.abs(Nindex-Zindex)==3) {
					 Nindex=0;
					 Zindex=move;
				 }
				 else {
					 System.out.println("Invalid move");
				 }		 
		 }
 }

	

	
