package newpackage;
interface BankAccount {
 void deposit(double amount);
 void withdraw(double amount);
}

class Account {
 String accountHolder;
 double balance;

 Account(String accountHolder, double balance) {
     this.accountHolder = accountHolder;
     this.balance = balance;
 }

 void displayBalance() {
     System.out.println("Balance: $" + balance);
 }

 void displayBalance(String currency) {
     System.out.println("Balance: " + currency + balance);
 }
void printTransactionHeader() {
	        System.out.println("=== TRANSACTION START ===");
	    }

  void printTransactionFooter() {
	        System.out.println("=== TRANSACTION END ===");
	    }
}

class SavingsAccount extends Account implements BankAccount {
 SavingsAccount(String accountHolder, double balance) {
     super(accountHolder, balance);
 }
 
 public void deposit(double amount) {
     balance += amount;
     System.out.println("Deposited $" + amount);
 }
 
 public void withdraw(double amount) {
	 
     if (amount > balance) {
         throw new IllegalArgumentException("Insufficient funds!");
     }
     balance -= amount;
     System.out.println("Withdraw $" + amount);
 }

 void displayBalance() {
     System.out.println(accountHolder + "'s Savings Account Balance: $" + balance);
 }
}

public class combinedprogram {
 public static void main(String[] args) {
     SavingsAccount sa = new SavingsAccount("Alice", 30000);
     sa.printTransactionHeader();
     
     sa.displayBalance();
     sa.deposit(10000);
     sa.displayBalance("USD ");
     try {
         sa.withdraw(250);  
     } catch (IllegalArgumentException e) {
         System.err.println("Exception: " + e.getMessage());
     }
     sa.displayBalance();
     
     sa.printTransactionFooter();
 }
}


