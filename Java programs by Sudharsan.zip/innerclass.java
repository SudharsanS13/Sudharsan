package javatraining;
import java.util.Scanner;
class outerClass{
	Scanner j = new Scanner(System.in);
	private int outtervar;
	public outerClass(int var) {
		outtervar=var;
	}
	public void outermethod() {
		int p = j.nextInt();
		System.out.println("My Age is :" +p);
	}
	public class innerClass{
		private int innervar;
		public innerClass(int var) {
			innervar=var;
		}
		public void innermethod() {
			
			System.out.println("Hope you are,fine");
		}
		public void accessouter() {
			System.out.println("Outer variable from the inner class : "+outtervar);
		}
	}
}
public class innerclass {
public static void main(String args []) {
	outerClass s = new outerClass(20);
	outerClass.innerClass i = s.new innerClass(30);
	i.innermethod();
	s.outermethod();
	i.accessouter();
	
}
}
