package javasample;
 class Ar{
	void show() {
		System.out.print("hi ");
	}
}
public class InnerClassAonuomus{
	static Ar s = new Ar() {
		 void show() {
			super.show();
			System.out.println("members");
		}
	};
	public static void main(String args[]) {
		s.show();
	}
	
}