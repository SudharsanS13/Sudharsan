package Class;

class Own {
	Own()
	   {
		System.out.println("Hello");
	}
}
	public class userdefinedexception {
	public static void main(String[] args)
	{
	   try
	   { 
	     Own obj = new Own();
	     throw obj; 
	   } 
	   catch (Own x) 
	   { 
	      System.out.println("Caught a user defined exception"+x); 
	   } 	
} 
	}