package sudharsan;
import java.util.Scanner;
class acedamy
{
	Scanner opt = new Scanner(System.in);
	double addition(){
	double ans;
	System.out.println("Enter the 1st number:");
	double i = opt.nextDouble();
	System.out.println("Enter the 2nd number:"); 
	double j = opt.nextDouble();
	ans =(i+j);
    return(ans);
	}
}
public class training3 {
	public static void main(String arg[]){		
		acedamy s1 = new acedamy();
	    double result =s1.addition();
	    System.out.println("sum of the output:" +result);
	 }
}

