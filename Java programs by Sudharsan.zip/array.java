package Class;
import java.util.Scanner;
public class array {
 public static void main(String arg[]) {
	try (Scanner opt = new Scanner(System.in)) {
		System.out.print("Salary amount is : ");
		int Salary = opt.nextInt();
		System.out.print("age is : ");
		int Age = opt.nextInt();
		System.out.println(" ");
		if(Salary>=20000 || Age<=25) {
			System.out.println("Congrats!You are eligible for loan");
			System.out.println(" ");
			System.out.print("loan amount : ");
			int loanamount = opt.nextInt();
			if(loanamount<=50000) {
				System.out.println(" ");
				System.out.println("Congrats!Loan has been Available for you!");
			}
			else {
				System.out.println(" ");
				System.out.println("Sorry!Maximum loan amount is 50000");
			}
		}
		else {
			System.out.println("Sorry!You are not eligible for Loan");
		}
	}
 }
	
}
