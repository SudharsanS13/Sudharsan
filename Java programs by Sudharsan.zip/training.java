package sample;
import java.util.Scanner;
class alpha
{
	public int addition(int i,int j) {
		int ans;
		ans = i+j;
		return (ans);
	}
}
public class training {
	public static void main(String[] args) {
		Scanner opt = new Scanner(System.in);
		alpha a1 = new alpha();
	    int result;
	    System.out.println("Enter the 1st number:");
	    int i = opt.nextInt();
	    System.out.println("Enter the 2nd number:");
	    int j = opt.nextInt();
	    result = a1.addition(i,j);
	    System.out.println("Sum of the number is :"+result);
	}
	
}
