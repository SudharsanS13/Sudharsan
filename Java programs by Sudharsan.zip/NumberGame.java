package packag;
import java.util.Scanner;
import java.util.Random;
public class NumberGame {
public static void main (String args[]) {
	Scanner scan = new Scanner(System.in);
	Random random = new Random();
	
	int minRange = 1;
	int maxRange =50;
	int maxAttempts = 10;
	int totalRounds = 0;
	int Score = 0;
	
	System.out.println("\n ******Welcome to the Number Game******");
	boolean playAgain = true;
	
	while(playAgain) {
		int generatednumber = random.nextInt(maxRange-minRange +1) + minRange;
		int attempts =0;
		boolean GuessCorrectly = false;
		System.out.println("\n Round : "+(totalRounds+1));
		System.out.println("\n System has generated a Number between "+minRange+" and "+maxRange+". You have "+maxAttempts+" attempts to guess the number. Good Luck!");
		totalRounds++;
		while(attempts<maxAttempts && !GuessCorrectly) {
			System.out.println("\nAttempt:"+(attempts+1)+"/"+maxAttempts);
			System.out.println("Enter Your Guess => ");
			int userGuess =scan.nextInt();
			scan.nextLine();
			if(userGuess < generatednumber) {
				System.out.println("\n It's too Low");
			}
			else if (userGuess > generatednumber) {
				System.out.println("\n It's too High");
			}
			else 
			{
				System.out.println("Wow!! You guessed the right one.");
				GuessCorrectly = true;
				Score++;
			}
			attempts++;
		}
		if(!GuessCorrectly) {
			System.out.println("\nOops! You have used up all your attempts.");
			System.out.println("The Correct number was:"+generatednumber);
		}
		System.out.println("\nWould you like to play this game again(Yes/No) =>");
		String playAgainResponse =scan.nextLine();
		if(!playAgainResponse.equalsIgnoreCase("yes")) {
			playAgain = false;
		}
	}
	System.out.println("\nGame over! Your score is :"+Score);
	System.out.println("Thanks for playing!");
}
}
