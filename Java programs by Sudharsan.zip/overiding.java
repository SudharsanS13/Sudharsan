package sudharsan;
class shape{
	void draw() {
		System.out.println("Drawing a Shape ");
	}
}
class hexogon extends shape{
	void draw() {
		System.out.println("Draw a Hexagon shape");			          						
	}
}
class circle extends shape{
	void draw(){
	    System.out.println("Draw a Circle shape");
	}
}
class square extends shape{
	void draw(){
	    System.out.println("Draw a Square shape");
	}
}													
public class overiding {
	public static void main(String arg[]) {
		hexogon h = new hexogon();
		h.draw();
		circle c = new circle();
		c.draw();
		square sq = new square();
		sq.draw();		
	}
}
