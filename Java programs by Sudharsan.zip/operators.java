package sudharsan1;

public class operators {
	public static void main(String arg[]) {
		String s1 = "Web";
		String s2 = "Web";
		String s3 = new String ("Web");
		String s4 = "WEB";
		String s5 = "ALPHA";
		
			System.out.println(s1==s2);
			System.out.println(s1==s3);
			System.out.println(s1==s1);
			System.out.println("------"+s3==s2);
			System.out.println("------"+s3.equals(s2));
			
			System.out.println(s1.equals(s2));
			System.out.println(s1.equals(s3));
			System.out.println(s1.equals(s5));
			System.out.println(s1.equalsIgnoreCase(s4));
	}
}
