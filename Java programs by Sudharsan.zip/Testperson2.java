package class1;
import Class.*;
public class Testperson2 extends Testperson {
 public static void main(String arg []) {
	 Testperson2 s = new Testperson2();
	 System.out.println(s.age);
 }
}
