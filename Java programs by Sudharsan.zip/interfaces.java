package javasample;
import java.util.Scanner;
interface drawing{
	void draw();
}
class Rectangle implements drawing{
	Scanner l = new Scanner(System.in);
	public void draw(){
		int a,b,i,j,s,p,n,x;
		System.out.print("Enter the number:");
		a = l.nextInt();
		System.out.println("");
		System.out.print("Enter the number:");
		b = l.nextInt();
		System.out.println("");
		for(i=0;i<2;++i) {
			for(j=0;j<2;++j) {
                p = b-a;
                System.out.println("Ans difference is:"+p);
                n = a+b;
                System.out.println("Ans Addition is:"+n);
                x = b*a;
                System.out.println("Ans difference is:"+x);
			}
		}
	}
}
class Circle implements drawing{
	public void draw(){
	    System.out.println("Successfully Created");
	}
}
public class interfaces {
public static void main (String arg[]) {
	Rectangle opt = new Rectangle();
	opt.draw();
	Circle opt1 = new Circle();
	opt1.draw();
}
}
