package packag;
import java.util.Scanner;
import java.util.Random;
public class RockPaperScissor {
public static void main(String args[]) {
	Scanner Op = new Scanner(System.in);
	Random Opt = new Random();
	String choices[] = {"Rock","Paper","Scissor"};
	int Times = 10;
	int attempts =0;
	while (attempts<Times && true) {
		System.out.println("1.Rock\n2.Paper\n3.Scissor\n4.Quit\n");
		System.out.print("Enter your choice (Rock, Paper, Scissor) :");
		int userChoice = Op.nextInt();
		System.out.println("");
		if (userChoice==4) {
			System.out.println("Good Bye");
		}
		else if (userChoice<1 && 3<userChoice) {
			System.out.println("Invalid choices! Give the valid choices");
		}
		String userSelection = choices[userChoice-1];
		String ComputerSelection = choices[Opt.nextInt(3)];
		System.out.println("Your choice is : "+userSelection);
		System.out.println("Computer choice is : "+ComputerSelection);
		if(userSelection==ComputerSelection) {
			System.out.println("                      Its a tie");
		}
		else if (userSelection.equals("Rock")&& ComputerSelection.equals("Scissor") ||
				userSelection.equals("Scissor")&& ComputerSelection.equals("Paper") ||
				userSelection.equals("Paper")&& ComputerSelection.equals("Rock")) {
			System.out.println("     **********************************************");
			System.out.println("                          You win");
			System.out.println("     **********************************************");
		}
		else {
			System.out.println("     -----------------------------------------------");
			System.out.println("                        Computer Win");
			System.out.println("     -----------------------------------------------");
		}
		System.out.println("you will play max 10 times. you attempt "+attempts+" times.then only you have "+Times--+" attempts.");
		attempts++;
		
}
	
}
}
