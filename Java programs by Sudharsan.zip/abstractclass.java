package sudharsan;
abstract class one {
	abstract void raid();
	abstract void run();
	   
}
public class abstractclass extends one{
   void raid() {
	   System.out.println("He Raid on the Horse");
   }
   void run() {
	   System.out.println("He Raid on the Horse");
   }
   
   public static void main (String arg[]) {
	   abstractclass s = new abstractclass();
	   s.raid();
   }

}
