package Class;

public class exceptionhandling {
	public static void main(String[] args) {
        try {
            int[] numbers = {34,56,67};
            System.out.println("Accessing element at index : " + numbers[3]);
        } 
        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Exception caught:" + e);
        } 
        finally {
            System.out.println("Finally block executed.");
        }

        System.out.println("Rest of the program continues...");
    }
}

