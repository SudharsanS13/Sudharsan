package javasample;
import java.util.Scanner;
public class BasicCalculator{
public static void main(String args[]) {
	Scanner op = new Scanner(System.in);
	
	System.out.println("***************************");
	System.out.println("     Basic calculator      ");
	System.out.println("***************************");
	System.out.println("");
	
	System.out.println(" (Available operators : +,-,*,/,%)");
	System.out.println("");
	
	System.out.print("Enter the 1st number : ");
	 double i = op.nextDouble();
	 System.out.println("");
	 
	 System.out.print("Enter the operation(+,-,*,/,%) : ");
	 char O = op.next().charAt(0);
	 System.out.println("");
	 
	 System.out.print("Enter the 2nd number : ");
	 double j = op.nextDouble();
	 System.out.println("");
	 
	 double result =0;
	 switch(O) {
	 case '+': 
		result = i+j;
	    break;
	 case '-': 
	    result = i-j;
		 break;
	 case '*': 
	    result = i*j;
		 break;
	 case '/': 
		if (j != 0) {
			result = i/j;
		}
		else {
			System.err.println("Error:not divisable by 0");
		}
		 break;
	 case '%' :
		 if (j != 0) {
				result = i%j;
			}
			else {
				System.err.println("Error:not divisable by 0");
			}
		break;
	 default:
	     System.out.println("Invalid number");
	     return;
	 }
	 System.out.println("Result :"+result);
} 
}
