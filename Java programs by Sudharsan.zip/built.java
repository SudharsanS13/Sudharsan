package sudharsan;

public class built {
	public static void main(String arg[]) {
		int i;
	String s1 = "I'm a Software developer in a reputed company";
	char [] opt = s1.toCharArray();
	 int len = opt.length;
	 System.out.println(len);
	 System.out.println("char array element");
	 for(i=0;i<len;i++) {		 
		 System.out.println(opt[i]);
	 }
}}
