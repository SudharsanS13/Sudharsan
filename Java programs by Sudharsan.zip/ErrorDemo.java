package javasample;
import java.util.Scanner;
//Abstract class
abstract class Calculator {
 int a, b;
Scanner opt = new Scanner(System.in);

 // Abstract method
 abstract int calculate();
}
 class AddCalculator extends Calculator {
	 int c;
	 AddCalculator(int a,int b) {
     System.out.println("Enter the number :");
 }
int calculate() {
	
	 int i = opt.nextInt();
	 int j = opt.nextInt();
	 a = i;
	 b = j;
	 int c = i + j;
	 System.out.println("Addition Ans:"+c);
	 return c;
}
}
class DivideCalculator extends Calculator {
 DivideCalculator(int a,int b) {
	 
 }   
 int calculate() {
	 int i = opt.nextInt();
	 int j = opt.nextInt();
	 a = i;
	 b = j;
	 int f  ;
     try {
         f= (a/b);
     } catch (ArithmeticException e) {
         System.out.println("Runtime Error: " +e);  
         return 0;
 }
	return 0;
 }
}

public class ErrorDemo {
       static int i;
       static int j;
public static void main(String[] args) {
	
	Calculator calc1 = new AddCalculator(i,j);
     Calculator calc2 = new DivideCalculator(i,j);
     calc1.calculate();
     calc2.calculate();
      }
}
