package sudharsan;
abstract class bike{
	abstract void run();
	bike(){
		System.out.println("bike is created");
	}
		void changegear() {
			System.out.println("gear changed");
		}
}
class honda extends bike{
			void run() {
				System.out.println("raid safely");
			}
}
public class abstrct {
public static void main(String args[]) {
	honda obt = new honda();
	obt.changegear();
	obt.run();
}
}

	