package sudharsan;
class person{
	private String name ;
	private int age;
	public person(String name,int age) {
		this.name = name;
		this.age = age;
	}
	public String getname() {
		return name;
	}
	public int getage() {
		return age;
	}
}
public class returnobject {
public static void main (String arg[]) {
	returnobject s = new returnobject();
	person p = s.createperson("Alice",21);
	System.out.println("Name :"+ p.getname());
	System.out.println("Age :"+ p.getage());	
}
 person createperson(String name, int age) {
	 return new person(name, age);
	
 }
}
