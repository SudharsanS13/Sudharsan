package javasample;
class one{
	private int a=10,b=20;
	class two{
		public void numbers() {
			int c = a+b;
			System.out.println(c);
		}
	}
}
public class InnerClassMember {
	public static void main(String args[]) {
one j = new one();
one.two i = j.new two();
    i.numbers();
}
}