package sample;
public class Sudharsann {
	public static void main(String args[]){
		System.out.println("Bio data");
		System.out.println("Name: Sudharsan");
		System.out.println("Degree & Branch: BE & Electronics and Communication Engineering");
		System.out.println("College Name: Vaigai College of Engineering");
		System.out.println("Training Course: Java");
		System.out.println("City: Srivilliputtur");
	}

}
