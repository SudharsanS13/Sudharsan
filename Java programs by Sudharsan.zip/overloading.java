package sudharsan1;
import java.util.Scanner;
class overloadings{
	double area(double l,double w,double h) {
	return l*w*h;
	}
	double area(double r,double h) {
	return 3.1416*r*r*h;
	}
	double area(double l) {
		return l*l*l;
	}
}
public class overloading {
public static void main(String arg[]) {
	Scanner s = new Scanner(System.in);
	overloadings a = new overloadings();
	double b,c,d,l,w,h,r;
	System.out.print("Enter your Length :");
	l = s.nextInt();
	System.out.println("");
	System.out.print("Enter your Width :");
	w = s.nextInt();
	System.out.println("");
	System.out.print("Enter your Height :");
	h = s.nextInt();
	System.out.println("");
	System.out.print("Enter your Radius :");
	r = s.nextInt();
	System.out.println("");
    b = a.area(l,w,h);
    System.out.println("Area of the rectangle : "+b);
    c = a.area(r,h);
    System.out.println("Area of the Cyclinder : "+c);
    d = a.area(l);
    System.out.println("Area of the cube : "+d);
}
}
