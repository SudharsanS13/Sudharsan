package sudharsan1;
class one {
	void academy() {
		System.out.println("My name is Sudharsan");
	}
}
class two extends one{
	void academy() {
	    System.out.println("Im studing Engineering");
	}
}
class three extends two{
	void academy() {
		System.out.println("Madurai");
	}
}
public class overridding {
public static void main(String[] arg) {
	two opt = new two();
	one op = new one();
	three o = new three();
	System.out.println("What is your Name?");
	op.academy();
    System.out.println("");
	System.out.println("What's your studies?");
    opt.academy();
    System.out.println("");
    System.out.println("Which is your studies location?");
    o.academy();
}
}
