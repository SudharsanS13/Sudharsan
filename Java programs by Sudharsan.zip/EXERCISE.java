package Sudharsan;
import java.util.Scanner;
import java.util.Arrays;

public class EXERCISE {
    private static final int SIZE = 9;
    private static int[] board = {1, 2, 3, 7, 5, 6, 4, 8, 0}; // 0 represents the empty space

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (!isSolved()) {
            printBoard();
            System.out.print("Enter number to move: ");
            int num = scanner.nextInt();
            move(num);
        }
        scanner.close();
        System.out.println("Congratulations! You solved the puzzle.");
    }

    private static void printBoard() {
        for (int i = 0; i < SIZE; i++) {
            System.out.print(board[i] == 0 ? "   " : board[i] + " ");
            if ((i + 1) % 3 == 0) System.out.println();
        }
    }

    private static boolean isSolved() {
        int[] solvedBoard = {1, 2, 3, 4, 5, 6, 7, 8, 0};
        return Arrays.equals(board, solvedBoard);
    }

    private static void move(int num) {
        int numIndex = -1, zeroIndex = -1;
        for (int i = 0; i < SIZE; i++) {
            if (board[i] == num) numIndex = i;
            if (board[i] == 0) zeroIndex = i;
        }
        if (numIndex != -1 && Math.abs(numIndex - zeroIndex) == 1 || Math.abs(numIndex - zeroIndex) == 3) {
            board[zeroIndex] = num;
            board[numIndex] = 0;
        } else {
            System.out.println("Invalid move!");
        }
    }
}
