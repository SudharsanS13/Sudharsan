package Class;
class Father{
	void land(){
		System.out.println("I bought a land ");
	}
}
class Son extends Father{
	void bike() {
	    System.out.println("I bought a bike");
	}
}
class Grandson extends Son{
	void toys() {
	    System.out.println("I play with toys");
	}
}
public class inheritance {
	public static void main(String arg[]) {
		Grandson opt = new Grandson();
		 opt.land();
		 opt.bike();
	     opt.toys();		
	}
}
