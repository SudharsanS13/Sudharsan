package sudharsan;
class Vehicle {
    private String brand;

    public Vehicle(String brand) {
       this.brand = brand;
    }

    public void displayDetails() {
        System.out.println("Brand: " + brand);
    }
}

class Car extends Vehicle {
    private int wheels;

    public Car(String brand, int wheels) {
        super(brand);
        this.wheels = wheels;
    }

    public void displayDetails() {
        super.displayDetails();
        System.out.println("Wheels: " + wheels);
    }

    public void startEngine() {
        System.out.println("Car engine started");
    }
}
class Bike extends Vehicle {
    private boolean hasSidecar;

    public Bike(String brand, boolean hasSidecar) {
        super(brand);
        this.hasSidecar = hasSidecar;
    }

    public void displayDetails() {
        super.displayDetails();
        System.out.println("Has sidecar: " + (hasSidecar ? "Yes" : "No"));
    }

    public void startEngine() {
        System.out.println("Bike engine started");
    }
}

public class EXERCIZE3 {
    public static void main(String[] args) {
        Car car = new Car("Toyota", 4);
        Bike bike = new Bike("Harley", true);
        
        car.displayDetails();
        (car).startEngine();
        System.out.println();
        
        bike.displayDetails();
        ((Bike)bike).startEngine();
    }
}





