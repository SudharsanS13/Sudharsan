package sudharsan;
import java.util.Scanner;
class web
{
	void addition(int i,int j) {
	int ans;
	ans = (i+j);
	System.out.println("Sum of the number is :"+ans);
    return;
	}
}
public class training1 {
	public static void main(String arg[]) {
	Scanner opt = new Scanner(System.in);
	web s1 = new web ();
    System.out.println("Enter the 1st number:");
    int i = opt.nextInt();
    System.out.println("Enter the 2nd number:");
    int j = opt.nextInt();
    s1.addition(i,j);
 }
}
