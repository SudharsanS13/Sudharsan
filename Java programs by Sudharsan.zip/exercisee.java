package sudharsan1;

abstract class shape{
	abstract double Areaa(int lengt,int breath,int radius);
}
class triangle extends shape{	
	int L, B;
	double T;
	double  Areaa(int lengt,int breath,int radius) {
		lengt = L;
	    breath = B;
	    T = 0.5*L*B;
	    return T;
}
}
class Circle extends shape{
	int R;
	double C;
	double Areaa(int lengt,int breath,int radius) {			
		radius = R;
		 C = 3.14*R*R;
	    return C;
	   }
}
public class exercisee {
public static void main (String args[]) {
	triangle s2 = new triangle();
	Circle s3 = new Circle();
	s2.Areaa(10,20,1);
	s3.Areaa(1,1,5);
}
}