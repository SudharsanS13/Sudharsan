package javatraining;
public class outterclass {
	public int numbers(int a,int b) {
		return a*b;
	}
public static void main(String args[]) {
	outterclass O = new outterclass();
	System.out.println(O.numbers(5, 10));
}
}
