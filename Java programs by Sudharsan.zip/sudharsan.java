package sample;

public class sudharsan {

	public static void main(String[] args) {
		System.out.println("HELLO SUDHARSAN");
		System.out.print("HELLO WORLD");

	}

}
