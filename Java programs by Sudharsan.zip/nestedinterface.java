package javasample;
interface one {
	void organs();
	interface two{
		void parts();
}
	}
class total implements one{
	public void parts() {
		System.out.print("Hi "); 
	}
   public void organs() {
    	System.out.println("Students");
    }
}
public class nestedinterface {
public static void main (String args[]) {
	total op = new total();
	
	op.parts();
  }
}
