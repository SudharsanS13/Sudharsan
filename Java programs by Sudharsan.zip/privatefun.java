package sample;
class main{
	public void coordinators(int a,int b) {
		System.out.println("hii");
		int d = a-b;
		System.out.println(d);
		set(a,b);
	}
	private void set(int x,int y) {
		System.out.println("hello");
		int c = x / y;
		System.out.println(c);
	}
}

public class privatefun {
public static void main(String arg[]) {
	main s = new main();
    s.coordinators(50,2);
}
}
