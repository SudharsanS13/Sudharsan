package sample;

public class ststic {
static int count ;
 static void counter(){
	 count++;
	 System.out.println(count);
 }
  public static void main(String arg []) {	
	  ststic.counter();
	  ststic.counter();
	  ststic.counter();
	  ststic.counter();
	  ststic.counter();
	  ststic.counter();
  }
}
