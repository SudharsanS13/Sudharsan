package javasample;
interface hello{
	void show();
}
public class roughc {
static hello h = new hello() {
	public void show()
	{
		System.out.println("I am in anonymous class");
	}
};
 public static void main(String args[]) {
	 h.show();
 }
}