package Class;
class one {
	protected int age = 10;
	void methodA() {
	try {
		System.out.println("inside a method A");
		throw new RuntimeException();
	}
	finally {
		System.out.println("A Finally");
	}
	}
	void methodB() {
		try {
			System.out.println("inside a method B");
			return;
		}
		finally {
			System.out.println("B Finally");
		}
	}
	void methodC() {
		try {
			System.out.println("inside a methode C");
			return;
		}
		finally {
			System.out.println("C Finally");
		}
	}
}
public class finally1 {
public static void main(String arg[]) {
	one s = new one();
	System.out.println(s.age);
	try {
		s.methodA();
	}
	catch(Exception p){
	    System.out.println("Exception is caught"+p);
	}
	s.methodC();
	s.methodB();
}
}
