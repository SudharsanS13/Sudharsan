package javatraining;
import javatraining.outter1;
class outter{
	private  void one() {
		System.out.println("hi");
	}
	 class inner{
		public  void two() {
			one();
			System.out.println("inside inner class method  :");
		}
	}
}
public class staticclass {
public static void main(String args[]) {
	outter.inner p = new outter.inner();
	
}
}
