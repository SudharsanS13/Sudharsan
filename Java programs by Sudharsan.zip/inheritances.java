 package sudharsan;
 class vehicle{
	 int year;
	 String brand;
	 void startengine() {
	 System.out.println("Start the engine"); 
	 }
 }
 class car extends vehicle{
	 String	fueltype;
	 void startengine() {
	 System.out.println("car engine starts");
	 }
 }
 class bus extends vehicle{
	 String loadcapacity;
	 void startengine() {
	 System.out.println("bus engine starts");
	 }
 }
public class inheritances {
public static void main(String arg[]) {
	car opt = new car();
	bus op = new bus();
	opt.brand = "thar";
	System.out.println("car name is " +opt.brand);
	opt.year=2002;
	System.out.println("car year is " +opt.year);
	opt.fueltype="petrol";
	System.out.println("car fuel type is " +opt.fueltype);
	opt.startengine();
	op.brand = "komban";
	System.out.println("bus name is " +op.brand);
	op.year = 2003;
	System.out.println("bus year is " +op.year);
	op.loadcapacity = "2 ton";
	System.out.println("bus loadcapacity is " +op.loadcapacity);
	op.startengine();
}
}
